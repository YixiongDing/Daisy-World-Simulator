/**
 * Sencerio enum.
 *
 * @author Shenglan Yu<shenglany1@student.unimelb.edu.au> - 808600
 * TODO: FILL your name and id
 *
 */
public enum Sencerio {
	
	RAMP_UP_RAMP_DOWN, STABLE;
	
}
