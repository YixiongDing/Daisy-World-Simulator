/**
 * Sencerio enum.
 *
 * @author Shenglan Yu<shenglany1@student.unimelb.edu.au> - 808600
 *		   Yixiong Ding - 671499
 *  	   Haohua Wu - 927081
 *
 */
public enum Scenario {
	
	RAMP_UP_RAMP_DOWN, STABLE;
	
}
