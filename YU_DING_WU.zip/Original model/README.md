# How to Run
  * Add your experiment parameters in the `parameter.txt` line by line,
    following the schema.
  * Run `bash script.sh`

