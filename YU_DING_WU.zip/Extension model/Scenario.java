/**
 * Sencerio enum.
 *
 * @author Shenglan Yu<shenglany1@student.unimelb.edu.au> - 808600
 * @author Haohua Wu<haohuaw@student.unimelb.edu.au> - 927081
 *
 */
public enum Scenario {
	
	RAMP_UP_RAMP_DOWN, STABLE;
	
}
